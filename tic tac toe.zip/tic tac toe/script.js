// Game variables
let turn = "X";
let isGameOver = false;
let scores = { X: 0, O: 0, draws: 0, totalGames: 0 };
let board = ["", "", "", "", "", "", "", "", ""];

// DOM elements
const boxes = document.querySelectorAll(".box");
const infoDisplay = document.querySelector(".info");
const resetBtn = document.getElementById("reset");
const newGameBtn = document.getElementById("new-game");
const xScoreDisplay = document.getElementById("x-score");
const oScoreDisplay = document.getElementById("o-score");
const totalGamesDisplay = document.getElementById("total-games");
const totalDrawsDisplay = document.getElementById("total-draws");
const line = document.querySelector(".line");
const imgBox = document.querySelector(".imgbox img");

// Audio elements
const audioTurn = new Audio("ting.mp3");
const gameoverAudio = new Audio("gameover.mp3");

// Initialize game
function initGame() {
    updateScores();
    infoDisplay.textContent = `Turn for ${turn}`;
}

// Handle box click
function handleBoxClick(box, index) {
    if (box.textContent === "" && !isGameOver) {
        box.textContent = turn;
        board[index] = turn;
        audioTurn.play();
        
        if (checkWin()) {
            endGame(false);
            return;
        }
        
        if (checkDraw()) {
            endGame(true);
            return;
        }
        
        turn = turn === "X" ? "O" : "X";
        infoDisplay.textContent = `Turn for ${turn}`;
    }
}

// Check for win
function checkWin() {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
        [0, 4, 8], [2, 4, 6]             // diagonals
    ];

    for (let pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            drawWinningLine(pattern);
            return true;
        }
    }
    return false;
}

// Draw winning line
function drawWinningLine(pattern) {
    const [a, b, c] = pattern;
    const box1 = document.querySelectorAll(".box")[a].getBoundingClientRect();
    const box3 = document.querySelectorAll(".box")[c].getBoundingClientRect();
    
    const container = document.querySelector(".container").getBoundingClientRect();
    
    // Calculate line position and angle
    const startX = box1.left + box1.width/2 - container.left;
    const startY = box1.top + box1.height/2 - container.top;
    const endX = box3.left + box3.width/2 - container.left;
    const endY = box3.top + box3.height/2 - container.top;
    
    const length = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
    const angle = Math.atan2(endY - startY, endX - startX) * 180 / Math.PI;
    
    line.style.width = `${length}px`;
    line.style.left = `${startX}px`;
    line.style.top = `${startY}px`;
    line.style.transform = `rotate(${angle}deg)`;
    line.style.transformOrigin = "0 0";
}

// Check for draw
function checkDraw() {
    return !board.includes("") && !isGameOver;
}

// End game
function endGame(isDraw) {
    isGameOver = true;
    gameoverAudio.play();
    
    if (isDraw) {
        infoDisplay.textContent = "Game Draw!";
        scores.draws++;
        scores.totalGames++;
    } else {
        infoDisplay.textContent = `${turn} Wins!`;
        scores[turn]++;
        scores.totalGames++;
        imgBox.style.width = "200px";
    }
    
    updateScores();
}

// Update score displays
function updateScores() {
    xScoreDisplay.textContent = `X: ${scores.X}`;
    oScoreDisplay.textContent = `O: ${scores.O}`;
    totalGamesDisplay.textContent = scores.totalGames;
    totalDrawsDisplay.textContent = scores.draws;
}

// Reset current game
function resetGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    turn = "X";
    isGameOver = false;
    
    boxes.forEach(box => {
        box.textContent = "";
    });
    
    infoDisplay.textContent = `Turn for ${turn}`;
    line.style.width = "0";
    imgBox.style.width = "0";
}

// Start new game (reset scores)
function newGame() {
    resetGame();
    scores = { X: 0, O: 0, draws: 0, totalGames: 0 };
    updateScores();
}

// Event listeners
boxes.forEach((box, index) => {
    box.addEventListener("click", () => handleBoxClick(box, index));
});

resetBtn.addEventListener("click", resetGame);
newGameBtn.addEventListener("click", newGame);

// Initialize game on load
window.addEventListener("load", initGame);